<?php

// Database configuratie
$db['host']="localhost";
$db['user']="root";
$db['pw']="usbw";
$db['name']="delijn";
$db['port']=3307;

$allowCors=true;
